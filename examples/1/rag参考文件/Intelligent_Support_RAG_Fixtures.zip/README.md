# Synthetic intelligent support RAG fixtures

All records are independently authored fictional test data, intended for generic customer support memory implementation. No external source data is needed. The archive includes source text, exact chunks, event versions, separate access policies, scoped entities/aliases, evidence links, revocations, retrieval gold cases and two legacy manual cards. No model training or production use is authorized.

1. Read `schema.md` and `Intelligent_Support_RAG_Data_Contract_and_Test.md`.
2. Run `python validate_fixtures.py` (Python standard library only). It verifies fixture structure and reference ACL eligibility, not actual retrieval quality.
3. Implement a versioned import adapter into the actual application contract, then run application integration tests for all queries and negative case descriptions. The latter are not pre-executed mutations.
4. `python build_fixtures.py` deterministically rebuilds the JSONL files and manifest; rerun validation. The included SHA256SUMS applies to the delivered frozen bytes.
5. Keep all fixtures marked fixture_only. Scopes and access grants are mock server records, not production credentials.
