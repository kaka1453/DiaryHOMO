"""Reference structural + access eligibility check, not search/ranking or production authorization."""
from pathlib import Path
import json, hashlib
from datetime import datetime
ROOT=Path(__file__).resolve().parent
def load(n):return [json.loads(x) for x in (ROOT/(n+'.jsonl')).read_text(encoding='utf-8').splitlines() if x.strip()]
def keyed(rows,k):
 d={r[k]:r for r in rows}; assert len(d)==len(rows),f'duplicate {k}';return d
def dt(s):return datetime.fromisoformat(s)
def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()
manifest=json.loads((ROOT/'manifest.json').read_text()); assert manifest['fixture_only'] and not manifest['production_authorized']
for n,num in manifest['counts'].items():assert len(load(n))==num,n
S=keyed(load('sources'),'source_id'); C=keyed(load('chunks'),'chunk_id'); P=keyed(load('permissions'),'permission_id'); Q=keyed(load('scopes'),'scope_id'); E=load('events'); R=load('revocations'); ENT=keyed(load('entities'),'entity_id')
assert all(not p['training_authorized'] for p in P.values())
for p in P.values(): assert all(x in Q and Q[x]['namespace']==p['namespace'] for x in p['allowed_scope_ids'])
for s in S.values():
 assert sha(s['text'])==s['content_sha256'] and s['permission_id'] in P
 assert P[s['permission_id']]['namespace']==s['namespace']
 if 'messages' in s:assert '\n'.join(m['speaker_id']+'：'+m['text'] for m in s['messages'])==s['text']
for c in C.values():
 s=S[c['source_id']]; a,b=c['char_start'],c['char_end']; assert 0<=a<b<=len(s['text']); assert s['text'][a:b]==c['text'] and sha(c['text'])==c['content_sha256']; assert c['permission_id'] in P
ref=lambda e:e['event_id']+'@'+str(e['version'])
assert len({ref(e) for e in E})==len(E)
for e in E:
 assert e['permission_id'] in P and P[e['permission_id']]['namespace']==e['namespace']; assert e['evidence_chunk_ids'] and all(x in C for x in e['evidence_chunk_ids'])
 assert all(x in ENT for x in e['subject_ids'])
 for claim in e['claims']:assert claim['evidence_chunk_ids'] and set(claim['evidence_chunk_ids'])<=set(e['evidence_chunk_ids'])
 if e['supersedes'] is not None:assert any(p['event_id']==e['event_id'] and p['version']==e['supersedes']<e['version'] for p in E)
for n in ['entities','aliases','event_links']:
 for r in load(n):assert r['permission_id'] in P and all(x in C for x in r['evidence_chunk_ids'])
for r in load('aliases'):assert r['entity_id'] in ENT
for r in load('event_links'):assert all(x in {e['event_id'] for e in E} for x in (r['from_event'],r['to_event']))
for r in R:assert r['event_id'] in {e['event_id'] for e in E}
def allowed(pid,scope):
 p=P[pid];return scope['namespace']==p['namespace'] and scope['scope_id'] in p['allowed_scope_ids'] and scope['purpose'] in p['allowed_purposes'] and all(p[k] for k in ['index_authorized','read_authorized','disclosure_authorized'])
def eligible(q):
 s=Q.get(q['scope_id']);
 if not s:return set()
 cutoff=dt(q['knowledge_as_of']); auth=dt(q['authorization_as_of']); out=set()
 for e in E:
  if dt(e['recorded_at'])>cutoff or (e['event_time'] and dt(e['event_time'])>cutoff):continue
  if e['status']!='active' or e['review_status']!='verified_fixture':continue
  if e['split']!=s['purpose'] or e['namespace']!=s['namespace'] or not allowed(e['permission_id'],s):continue
  if any(r['event_id']==e['event_id'] and dt(r['effective_at'])<=auth for r in R):continue
  # Do not reactivate superseded current-state cards for historical queries. Separate historical observations are provided.
  if e['version']!=max(x['version'] for x in E if x['event_id']==e['event_id']):continue
  if any(not allowed(C[c]['permission_id'],s) or not allowed(S[C[c]['source_id']]['permission_id'],s) or S[C[c]['source_id']]['split']!=s['purpose'] or dt(S[C[c]['source_id']]['recorded_at'])>cutoff for c in e['evidence_chunk_ids']):continue
  out.add(ref(e))
 return out
for q in load('queries'):
 a=eligible(q); assert set(q['required_event_refs'])<=a,(q['query_id'],'required evidence not eligible',set(q['required_event_refs'])-a)
 assert not (set(q['forbidden_by_policy'])&a),(q['query_id'],'forbidden eligible',set(q['forbidden_by_policy'])&a)
 assert set(q['alternative_event_refs'])<=a,(q['query_id'],'alternative not eligible')
 if q['expect_no_relevant_evidence']:assert not q['required_event_refs']
 # relevance (including empty results) is not verified by this ACL-only validator
for row in load('manual_cards'):
 c=row['card']; s=Q[row['scope_id']]; assert c['scope']=='session_only' and c['session_id']==s['session_id'] and c['namespace']==s['namespace']; assert c['permissions']=={'read':True,'train':False}; assert c['facts'] and c['event_time'] and c['recorded_at']
if (ROOT/'SHA256SUMS').exists():
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1); assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
print('PASS: manifest counts, source hashes, spans, foreign keys, fixture version/ACL eligibility and manual card shape')
print(f"{len(S)} sources, {len(C)} chunks, {len(E)} event versions, {len(load('queries'))} query eligibility cases, {len(load('negative_cases'))} negative-case descriptions")
print('NOT RUN: application import, actual retrieval/ranking, negative mutation execution, tokenizer, model generation, production ACL')
